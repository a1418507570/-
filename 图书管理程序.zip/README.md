﻿# xiau_c_shortsemester
小学期的C语言程序设计作业
Land是学生教师用户
Adminland是管理员用户
Library是图书信息
Reader是借阅信息
祝生活愉快！！！

